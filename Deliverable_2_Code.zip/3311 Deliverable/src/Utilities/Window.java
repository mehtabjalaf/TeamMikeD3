package Utilities;
/**
 * 
 * @version 2.0
 * Window Interface which each window inherits from. Contains all the shared attributes and methods.
 *
 */
public interface Window {

}
