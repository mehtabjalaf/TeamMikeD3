package Utilities;
/**
 * 
 * @version 2.0 
 * Interface which each visualization will inherit from. Contains all the shared attributes and methods.
 *
 */
public interface Visualizations {

}
