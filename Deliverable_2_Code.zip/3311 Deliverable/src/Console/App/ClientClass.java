package Console.App;

/**
 * @version 2.0
 * The class which will be provided to users and become their main source to access the app.
 * Hides all implementation but calls on MainWindow to create an instance and open the GUI.
 *
 */
public class ClientClass {

	public ClientClass() {
	}

	public static void main(String[] args) {
	}

}
